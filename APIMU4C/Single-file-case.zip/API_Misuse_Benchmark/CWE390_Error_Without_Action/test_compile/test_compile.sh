for file in `find . -name "*.c"`
do
	echo $file
	clang -D INCLUDEMAIN $file -S -g -emit-llvm
done