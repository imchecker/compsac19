for file in `find . -name "*.c"`
do
	echo $file
	#echo ${file/CWE121_Stack_Based_Buffer_Overflow__C/C}
	# echo ${file/CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove/CWE131_Incorrect_Cal_BufSize_memmove}$
	#cp $file ${file/CWE121_Stack_Based_Buffer_Overflow__C/C}
	# echo ${file/CWE121_Stack_Based_Buffer_Overflow__C/C}
	
	# rm $file
	echo ${file/CWE390_Error_Without_Action__f/f}
	cp $file ${file/CWE390_Error_Without_Action__f/CWE390_ErrorEP_}
done